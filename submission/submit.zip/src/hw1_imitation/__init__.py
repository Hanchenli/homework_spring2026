"""Course package for hw1 imitation."""
